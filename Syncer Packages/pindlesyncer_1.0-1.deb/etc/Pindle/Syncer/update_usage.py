import json
import os
import time, threading,shutil
import googledrive
import onedrive

class syncer():
    def __init__(self):
        self.WAIT_SECONDS = 120
        with open('/etc/Pindle/Syncer/localname.json') as f:
            self.details = json.load(f)
        self.mail = self.details['mailid']
        self.instdir = self.details['insdir']
        self.domain = self.mail[self.mail.index('@') + 1:]
        self.localname = self.details['localname']
        if self.domain != "gmail.com":
            self.api = onedrive.LoadSession()
        else:
            self.api = googledrive.authenticate()
    
    def get_config(self):
        if self.domain != "gmail.com":
            onedrive.download(self.api, "pindleconfig.json",
                              os.path.join(self.instdir, "pindleconfig.json"), 'file')
        else:
            googledrive.download(self.api, "pindleconfig.json", self.instdir, 'file')

    def sync(self):
        self.get_config()
        with open('/etc/Pindle/Syncer/pindleconfig.json','r') as f:
            config = json.loads(f.read())

        if config['device1']['name'] == self.details['localname']:
            config['device1']['size'] = shutil.disk_usage('/')
        else:
            config['device2']['size'] = shutil.disk_usage('/')

        with open(os.path.join(self.instdir,'pindleconfig.json'), 'w+') as f:
            json.dump(config, f)

        if self.domain == "gmail.com":
            googledrive.upload(self.api, os.path.join(self.instdir, 'pindleconfig.json'), "Pindle", 'file')
        else:
            onedrive.upload(self.api, "Pindle", os.path.join(self.instdir, 'pindleconfig.json'), 'folder')
        print("uploaded {}".format(time.ctime()))
        threading.Timer(self.WAIT_SECONDS, self.sync).start()

sync1 = syncer()
sync1.sync()