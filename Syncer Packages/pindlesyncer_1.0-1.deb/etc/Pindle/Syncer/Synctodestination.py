#!/usr/bin/python3
import json
import os
import time
from os.path import dirname, join

from watchdog.events import LoggingEventHandler
from watchdog.observers import Observer

import googledrive
import onedrive

class Changes():
    def __init__(self):
        self.mapped = None
        self.queue = []
        self.updates = {}
        self.paths = self.load_sessions()
        self.syncnow()

    def syncnow(self):
        if self.domain != "gmail.com":
            onedrive.download(self.api, "{}_changes.json".format(self.tosave),
                              os.path.join("/tmp", "{}_changes.json".format(self.tosave)), 'file')
        else:
            googledrive.download(self.api, "{}_changes.json".format(self.tosave), '/tmp', 'file')

        with open("/tmp/{}_changes.json".format(self.tosave), 'r') as f:
            self.oldconf = json.load(f)

        with open("/etc/Pindle/Syncer/{}_changes.json".format(self.tosave), 'r') as f:
            self.uploadnow = json.load(f)

        for item in self.uploadnow['queue']:
            if item in self.oldconf['queue']:
                self.oldconf['queue'].remove(item)

        self.queue = self.oldconf['queue']+self.uploadnow['queue']
        self.updates = {**self.uploadnow['updates'],**self.oldconf['updates']}
        self.mapped = {**self.uploadnow['mapped'],**self.oldconf['mapped']}

        self.save()
        for dequeue in self.uploadnow['queue']:
            if self.updates[dequeue][1] != 'deleted':
                self.upload(self.mapped.get(dequeue), dequeue)

    def load_sessions(self):
        try:
            with open('/etc/Pindle/Syncer/localname.json') as f:
                self.details = json.load(f)
        except:
            exit(0)

        self.instdir = self.details['insdir']
        self.mail = self.details['mailid']
        self.domain = self.mail[self.mail.index('@') + 1:]
        self.localname = self.details['localname']
        try:
            self.get_config()
        except:
            print("file not found ")
            exit(0)

        with open(os.path.join(self.instdir, 'pindleconfig.json'), 'r') as f:
            self.changes = json.load(f)

        if self.changes['device1']['name'] == self.details['localname']:
            self.basedonkey = True
            self.tosave = self.changes['device2']['name']
            self.addwatch = self.changes["connections"].keys()
        else:
            self.basedonkey = False
            self.addwatch = self.changes["connections"].values()
            self.tosave = self.changes['device1']['name']
        return self.changes['connections']

    def get_config(self):
        if self.domain != "gmail.com":
            self.api = onedrive.LoadSession()
            onedrive.download(self.api, "pindleconfig.json", os.path.join(self.instdir, "pindleconfig.json"), 'file')
        else:
            self.api = googledrive.authenticate()
            googledrive.download(self.api, "pindleconfig.json", self.instdir, 'file')

    def upload(self, src, osrc):
        try:
            globals()['watcher'].pause()
        except:
            print("exception")
            pass
        print("src {} osrc {}".format(src,osrc))
        print("c1")
        cmd ='cp "{}" "{}"'.format(src, join(dirname(src), osrc))
        print(cmd)
        os.system(cmd)
        print("C2")
        if self.domain != "gmail.com":
            onedrive.upload(self.api, 'Pindle', join(dirname(src), osrc), 'folder')
        else:
            googledrive.upload(self.api, join(dirname(src), osrc), "Pindle", 'file')
        print("c3")
        cmd = 'rm -f "{}"'.format(join(dirname(src), osrc))
        print(cmd)
        os.system(cmd)
        print("c4")
        try:
            globals()['watcher'].resume()
        except:
            pass
        print("c5")
        self.save()

    def save(self):
        self.sync = {}
        self.sync['updates'] = self.updates
        self.sync['queue'] = self.queue
        self.sync['mapped'] = self.mapped
        with open('/etc/Pindle/Syncer/{}_changes.json'.format(self.tosave), 'w+') as f:
            json.dump(self.sync, f)

        if self.domain != "gmail.com":
            onedrive.upload(self.api, 'Pindle', "/etc/Pindle/Syncer/{}_changes.json".format(self.tosave), 'folder')
        else:
            googledrive.upload(self.api, "/etc/Pindle/Syncer/{}_changes.json".format(self.tosave), "Pindle", 'file')

def on_create(src):
    osrc = src.replace("/", "-")
    paths.mapped[osrc] = src
    if osrc in paths.queue:
        paths.queue.remove(osrc)
    paths.queue.append(osrc)
    if paths.basedonkey == True:
        location = paths.paths[dirname(src)]
    else:
        location = list(paths.paths.keys())[list(paths.paths.values()).index(dirname(src))]
    paths.updates[osrc] = (location, "created")
    print(paths.updates)
    print(paths.queue)
    print('uploading ' + src)
    paths.upload(src, osrc)

def on_deleted(src):
    osrc = src.replace("/", "-")
    paths.mapped[osrc] = src
    if osrc in paths.queue:
        paths.queue.remove(osrc)
    paths.queue.append(osrc)
    if paths.basedonkey == True:
        location = paths.paths[dirname(src)]
    else:
        location = list(paths.paths.keys())[list(paths.paths.values()).index(dirname(src))]
    paths.updates[osrc] = (location, "deleted")
    paths.save()

class PausingObserver(Observer):
    def dispatch_events(self, *args, **kwargs):
        if not getattr(self, '_is_paused', False):
            super(PausingObserver, self).dispatch_events(*args, **kwargs)

    def pause(self):
        self._is_paused = True

    def resume(self):
        time.sleep(2)  # allow interim events to be queued
        self.event_queue.queue.clear()
        self._is_paused = False

class Event(LoggingEventHandler):
    @staticmethod
    def on_any_event(event, **kwargs):
        if event.is_directory:
            # print(event)
            return None
        # Create a watchdog in Python to look for filesystem changes
        elif event.event_type == 'created' or event.event_type == "modified":
            try:
                print("created event")
                on_create(event.src_path)
            except:
                pass
        elif event.event_type == 'deleted':
            try:
                print("deleted")
                on_deleted(event.src_path)
            except:
                pass

if __name__ == "__main__":
    paths = Changes()
    event_handlers = Event()
    globals()['watcher'] = PausingObserver()
    threads = []

    for i in paths.addwatch:
        targetPath = i
        print(i)
        globals()['watcher'].schedule(event_handlers, targetPath, recursive=False)
        threads.append(globals()['watcher'])

    try:
        globals()['watcher'].start()
        globals()['watcher'].join()
    except KeyboardInterrupt:
        globals()['watcher'].stop()