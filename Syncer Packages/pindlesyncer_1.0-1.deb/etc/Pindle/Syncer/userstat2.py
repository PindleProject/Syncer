#!/usr/bin/python3
import json
import os
import sys
import time

from PyQt5 import QtWidgets,QtCore
from PyQt5.QtGui import QMovie
from PyQt5 import uic
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QErrorMessage, QMainWindow, QListWidgetItem

import source_tree_items
import googledrive
import onedrive


class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()
        uic.loadUi("/etc/Pindle/Syncer/userstat2.ui", self)
        self.setWindowTitle("Pindle Syncer")
        self.setGeometry(0,0, 840, 700)
        self.centerOnScreen()
        self.setWindowIcon(QIcon("/usr/share/pixmaps/Pindle/Syncer/sync.png"))
        self.error_dialog = QErrorMessage()
        self.load()
        self.pushButton.clicked.connect(self.back)
        self.pushButton_2.clicked.connect(self.edit)

    def load(self):
        try:
            with open('/etc/Pindle/Syncer/localname.json') as f:
                self.details = json.load(f)
        except:
            self.error_dialog.showMessage("localname.json file not found")
            time.sleep(10)
            exit(0)

        self.mail = self.details['mailid']
        domain = self.mail[self.mail.index('@') + 1:]
        self.instdir = self.details['insdir']
        if domain != "gmail.com":
            api = onedrive.LoadSession()
            onedrive.download(api, "pindleconfig.json", os.path.join(self.instdir,"pindleconfig.json"), 'file')
        else:
            api = googledrive.authenticate()
            googledrive.download(api, "pindleconfig.json", self.instdir, 'file')

        with open('/etc/Pindle/Syncer/pindleconfig.json','r') as f:
            self.config = json.load(f)

        self.label.setText(self.config['device1']['name'])
        self.label_2.setText(self.config['device2']['name'])

        if self.config['connections'] == {}:
           self.error_dialog.showMessage("Noting to Sync!!\n Add something by Edit")
        else:
            for key,value in self.config['connections'].items():
                item = QListWidgetItem(key)
                self.listWidget.addItem(item)
                item = QListWidgetItem(value)
                self.listWidget_2.addItem(item)

    def centerOnScreen(self):
        resolution = QtWidgets.QDesktopWidget().screenGeometry()
        self.move((resolution.width() // 2) - (self.frameSize().width() // 2),
                  (resolution.height()// 2) - (self.frameSize().height()// 2))

    def back(self):
        self.label_5.setGeometry(QtCore.QRect(280, 250, 400, 180))
        self.label_5.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie1 = QMovie('/usr/share/pixmaps/Pindle/Syncer/waited.gif')
        self.label_5.setMovie(self.movie1)
        timer1 = QtCore.QTimer(self)
        self.movie1.start()
        timer1.singleShot(3000, self.stopanime)

    def stopanime(self):
        from firstwindowone import secondwin
        self.win=secondwin()
        self.win.show()
        self.movie1.stop()
        self.close()

    def edit(self):
        self.trying()

    def trying(self):
        self.label_5.setGeometry(QtCore.QRect(280, 250, 400, 180))
        self.label_5.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie = QMovie('/usr/share/pixmaps/Pindle/Syncer/waited.gif')
        self.label_5.setMovie(self.movie)
        timer= QtCore.QTimer(self)
        self.movie.start()
        timer.singleShot(9000, self.stopanimation)

    def stopanimation(self):
        self.window = source_tree_items.UI()
        self.window.show()
        self.movie.stop()
        self.close()


if __name__ == "__main__":
    arr=  QtWidgets.QApplication(sys.argv)
    pi=UI()
    pi.show()
    arr.exec_()


