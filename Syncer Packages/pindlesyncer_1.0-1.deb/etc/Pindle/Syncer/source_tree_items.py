#!/usr/bin/python3
from collections import defaultdict
import time
from PyQt5 import QtWidgets,QtCore
from PyQt5.QtGui import QMovie
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QErrorMessage, QMainWindow, QLabel, QApplication, QPushButton, QFileSystemModel, QTreeView, \
    QListWidget, QListWidgetItem, QAbstractItemView
from PyQt5 import uic
import sys
from os.path import basename, dirname
import json
import onedrive, googledrive
import os
import userstat2,map_items

class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()
        uic.loadUi("/etc/Pindle/Syncer/sourcedir.ui", self)
        self.setWindowTitle("Edit Directories")
        self.setGeometry(0,0, 840, 700)
        self.centerOnScreen()
        self.setWindowIcon(QIcon("/usr/share/pixmaps/Pindle/Syncer/sync.png"))
        self.error_dialog = QErrorMessage()
        self.heading = self.findChild(QLabel,"label")
        self.loadpaths()
        self.listview = self.findChild(QListWidget, "listWidget")
        self.tree = self.findChild(QTreeView, "DirectoryView")
        self.remove = self.findChild(QPushButton, "pushButton_4")
        self.back = self.findChild(QPushButton, "pushButton")
        self.listview.setDragDropMode(QAbstractItemView.InternalMove)
        self.model = QFileSystemModel()
        self.model.setReadOnly(True)
        self.model.setRootPath('/')
        self.tree.setModel(self.model)
        self.tree.header().hideSection(1)
        self.tree.header().hideSection(2)
        self.tree.header().hideSection(3)
        self.paths_tolist()
        self.tree.clicked.connect(self.add_dir)
        self.remove.clicked.connect(self.remove_dir)
        self.back.clicked.connect(self.goback)
        self.pushButton_2.clicked.connect(self.next)

    def paths_tolist(self):
        for direc in self.paths:
            item = QListWidgetItem(direc)
            self.listview.addItem(item)

    def centerOnScreen(self):
        resolution = QtWidgets.QDesktopWidget().screenGeometry()
        self.move((resolution.width() // 2) - (self.frameSize().width() // 2),
                  (resolution.height() // 2) - (self.frameSize().height() // 2))

    def next(self):
        self.trying()

    def trying(self):
        self.label_2.setGeometry(QtCore.QRect(310, 190, 400, 180))
        self.label_2.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie = QMovie('/usr/share/pixmaps/Pindle/Syncer/waited.gif')
        self.label_2.setMovie(self.movie)
        timer=QtCore.QTimer(self)
        self.movie.start()
        timer.singleShot(7000, self.stopanimation)

    def stopanimation(self):
        self.savepaths()
        self.window = map_items.UI()
        self.window.show()
        self.movie.stop()
        self.close()

    def goback(self):
        self.label_2.setGeometry(QtCore.QRect(310, 190, 400, 180))
        self.label_2.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie1 = QMovie('/usr/share/pixmaps/Pindle/Syncer/waited.gif')
        self.label_2.setMovie(self.movie1)
        timer1 = QtCore.QTimer(self)
        self.movie1.start()
        timer1.singleShot(6000, self.stopanime)

    def stopanime(self):
        self.savepaths()
        self.win = userstat2.UI()
        self.win.show()
        self.movie1.stop()
        self.close()

    def add_dir(self,index):
        direc = self.model.filePath(index)
        if direc in self.paths:
            self.error_dialog.showMessage('Directory is already in a list!!')
        elif not os.path.isdir(direc):
            self.error_dialog.showMessage('Can not file in a list!!')
        else:
            item = QListWidgetItem(direc)
            self.paths.append(direc)
            self.listview.addItem(item)

    def remove_dir(self):
        listItems = list(self.listview.selectedItems())
        if not listItems: return
        for item in listItems:
            index = self.listview.indexFromItem(item)
            self.listview.takeItem(index.row())
            self.paths.remove(item.text())
            try:
                if self.basedonkey == True:
                    del self.mapped[dirname(item.text())]
                else:
                    del list(self.mapped.keys())[list(self.mapped.values()).index(dirname(item.text()))]
            except:
                pass

    def loadpaths(self):
        try:
            with open('/etc/Pindle/Syncer/localname.json','r') as f:
                self.details = json.load(f)
        except:
            self.error_dialog.showMessage("localname.json file not found")
            time.sleep(10)
            exit(0)

        self.heading.setText(self.details['localname'])
        self.instdir = self.details['insdir']
        self.mail = self.details['mailid']
        self.domain = self.mail[self.mail.index('@') + 1:]
        if self.domain != "gmail.com":
            self.api = onedrive.LoadSession()
            onedrive.download(self.api, "pindleconfig.json", os.path.join(self.instdir,"pindleconfig.json"), 'file')
        else:
            self.api = googledrive.authenticate()
            googledrive.download(self.api, "pindleconfig.json", self.instdir, 'file')

        with open(os.path.join(self.instdir,'pindleconfig.json'), 'r') as f:
            self.config = json.load(f)

        if self.config['device1']['name'] == self.details['localname']:
            self.paths = self.config['device1']['connections']
            self.basedonkey = True
        else:
            self.basedonkey = False
            self.paths = self.config['device2']['connections']

        self.mapped = self.config['connections']

        if self.paths == []:
            self.error_dialog.showMessage("No files/folders in list")


    def savepaths(self):
        self.connections = {}
        if self.basedonkey == True:
            self.config['device1']['connections'] = self.paths
        else:
            self.config['device2']['connections'] = self.paths

        self.config['connections'] = self.mapped

        with open(os.path.join(self.instdir, 'pindleconfig.json'), 'w+') as json_file:
            json.dump(self.config, json_file)
        if self.domain != "gmail.com":
            onedrive.upload(self.api, "Pindle", os.path.join(self.instdir,'pindleconfig.json'),'folder')
        else:
            googledrive.upload(self.api, os.path.join(self.instdir,'pindleconfig.json'), "Pindle", 'file')

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UI()
    window.show()
    app.exec_()
